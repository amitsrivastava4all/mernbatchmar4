import React from 'react'

export const ShareContext = React.createContext({a:0, plusA:(val)=>{}});