import React from 'react';
import {F} from './F';
import {G} from './G';
export const C=React.memo(()=> {
    console.log('C Render Call');
    return (
        <div>
            C Component
            <F/>
            <G/>
        </div>
    )
});
