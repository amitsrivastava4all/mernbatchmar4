import React, {useState} from 'react';
import { ShareContext } from '../utils/ShareContext';

export const D=()=> {
    const [a, setA] = useState(0);
     const plus = ()=>{
            setA(a+1);
    }
    console.log('D Render Call');
    return (
        <ShareContext.Consumer>
            {
                (value) =>{
                    return (
                        <div>
                        D Component
                        <button onClick = {()=>{
                            plus();
                            value.plusA(a+1);
                        }}>Plus {a} {value.a}</button>
                    </div>
                    )
                }
            }
       
        </ShareContext.Consumer>
    )
}
