import React from 'react';

export const F=()=> {
    console.log('F Render Call');
    return (
        <div>
            F Component
        </div>
    )
}
