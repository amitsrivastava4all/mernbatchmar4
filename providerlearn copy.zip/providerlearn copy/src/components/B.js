import React from 'react';
import {D} from './D';
import {E} from './E';
export const B=React.memo(()=> {
    console.log('B Render Call');
    return (
        <div>
            B Component
            <D/>
            <E/>
        </div>
    )
});
