import React from 'react';
import { ShareContext } from '../utils/ShareContext';

export const G=()=> {
    console.log('G Render Call');
    return (
        <ShareContext.Consumer>
            {
                (value)=>{
                   return (<> G Component {value.a} </>);
                }
            }
        
        </ShareContext.Consumer>
    )
}
