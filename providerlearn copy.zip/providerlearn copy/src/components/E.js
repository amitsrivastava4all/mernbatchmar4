import React from 'react';

export const E=()=> {
    console.log('E Render Call');
    return (
        <div>
            E Component
        </div>
    )
}
