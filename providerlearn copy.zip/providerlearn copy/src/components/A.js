import React, {useState} from 'react';
import {B} from './B';
import {C} from './C';
import {ShareContext} from '../utils/ShareContext';
export const A=()=> {
    //let a = 111110;
    const [a, updateA] = useState(0);
    const plusA = (val)=>{
     // a= val;
     updateA(val);
      console.log('Now A is ',val);
    }
    console.log('A Render Call');
    return (
        <ShareContext.Provider value={{a:a, plusA:plusA}}>
        <div>

            A Component
            <B/>
            <C/>
        </div>
        </ShareContext.Provider>
    )
}
