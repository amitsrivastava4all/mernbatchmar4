import logo from './logo.svg';
import './App.css';
import {A} from './components/A';
 
function App() {
  return (
    <A/>
  );
}

export default App;
