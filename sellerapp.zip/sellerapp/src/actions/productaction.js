export const productAction  = (payload, type)=>{
    return {
        "payload":payload,
        "type":type
    }
}