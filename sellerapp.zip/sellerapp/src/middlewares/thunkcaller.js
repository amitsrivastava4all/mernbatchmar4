export const productActionLazy = (payload, type)=>{
    return dispatch=>{
        setTimeout(()=>{
            dispatch({
                type:type, payload:payload
            })
        },5000);
    }
}
   