import logo from './logo.svg';
import './App.css';
import { SellerCrud } from './containers/SellerCrud';
import { Shop } from './containers/Shop';

function App() {
  return (
    <div className='container'>
      <Shop/>
    </div>
  );
}

export default App;
