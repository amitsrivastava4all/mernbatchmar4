import React from 'react'
import {useSelector} from 'react-redux'

export const Result = ()=>{
    const products = useSelector((state)=>state.products);
    return (<h3>Total Records {products.length} Marked Records  UnMark Records</h3>)
}