export const Operations = ()=>{

    const deleteRec = ()=>{

    }

    const update = ()=>{

    }

    const search = ()=>{

    }

    const sort = ()=>{

    }

    const clearAll = ()=>{

    }

    const save = ()=>{

    }

    const load = ()=>{

    }

    return (
    <>
    <button className ='btn btn-danger' onClick = {deleteRec}>Delete</button> &nbsp;
    <button className ='btn btn-info' onClick = {update}>Update</button>&nbsp;
    <button className ='btn btn-secondary' onClick = {search}>Search</button>&nbsp;
    <button className ='btn btn-warning' onClick = {sort}>Sort</button>&nbsp;
    <button className ='btn btn-danger' onClick = {clearAll}>Clear All</button>&nbsp;
    <button className ='btn btn-success' onClick = {save}>Save</button>&nbsp;
    <button className ='btn btn-info' onClick = {load}>Load</button>
    </>
    )
}