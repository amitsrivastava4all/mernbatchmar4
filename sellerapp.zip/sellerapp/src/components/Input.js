import React, {useRef, useState} from 'react'
import { useHistory } from 'react-router';
import { productAction } from '../actions/productaction';
import { productActionLazy } from '../middlewares/thunkcaller';
import { store } from '../models/store';
export const Input = (props)=>{
    const id = useRef(0);
    const name = useRef('');
    const descr = useRef('');
    const price = useRef(0.0);
    const url = useRef('');
    const date = useRef('');
    const history = useHistory();
    const [idError, setIdError] = useState('');
    const add = ()=>{
        if(id.current.value.length==0){
            setIdError('Id is Empty');
            return ;
        }
        const data = {
           "id": id.current.value,
           "name": name.current.value,
           "descr": descr.current.value,
           "price": price.current.value,
           "url": url.current.value, 
           "date": date.current.value,
        }
       // store.dispatch(productActionLazy(data,'ADD'));
        store.dispatch(productAction(data,'ADD'));
        history.push("/search/BrainMentors/Delhi");
        console.log('Props ',props);
        console.log(data);
    }
    return (
    <>
    <div className='form-group'>
        <label>ID</label>
        <input className='form-control' type='text' placeholder='Type Id' ref={id}/>
        <span className='alert-danger'>{idError}</span>
    </div>
    <div className='form-group'>
        <label>Name</label>
        <input className='form-control' type='text' placeholder='Type Id' ref={name}/>
    </div>
    <div className='form-group'>
        <label>Descr</label>
        <input  className='form-control'   type='text' placeholder='Type Id' ref={descr}/>
    </div>
    <div className='form-group'>
        <label>Price</label>
        <input  className='form-range'  type='range' min="1" max="100" ref={price}/>
    </div>
    <div className='form-group'>
        <label>Date</label>
        <input  className='form-control' type='date'  ref={date}/>
    </div>
    <div className='form-group'>
        <label>URL</label>
        <input className='form-control' type='text' placeholder='Type Id' ref={url}/>
    </div>
    <div>
        <button onClick={add} className='btn btn-primary'>Add</button>
        
    </div>
    </>
    )

}