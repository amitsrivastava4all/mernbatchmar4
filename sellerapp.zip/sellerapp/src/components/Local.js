import React from 'react'

export const Local = ()=>{
    return (<h1>Local Locations - India</h1>)
}