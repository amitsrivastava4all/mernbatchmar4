import React from 'react'

export const Error = ()=>{
    return (<h1>OOPS Something wrong in Application</h1>)
}