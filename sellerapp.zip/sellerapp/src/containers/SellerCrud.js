import React, {useEffect} from 'react'
import { Input } from '../components/Input'
import  List  from '../components/List'
import { Operations } from '../components/Operations'
import { Result } from '../components/Result'

export const SellerCrud = (props)=>{

    useEffect(()=>{
        console.log("Component Did Mount");
        throw new Error("Something Wrong...");
    },[]);

    let data = props.location.search;
    const query = new URLSearchParams(data);
    let value = '';
    for(let param of query.entries()){
        value += param;
    }
    return (
        <>
        
        <h1 className='alert-info text-center'>Seller CRUD - {value.split(',')[1]} </h1>
        <Input/>
        <Operations/>
        <Result/>
        <List/>
        </>
    )
}
