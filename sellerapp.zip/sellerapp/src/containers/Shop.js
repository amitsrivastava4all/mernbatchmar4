import { Redirect, Route, Switch } from "react-router"
import { Menu } from "../widgets/Menu"
import { AboutUs } from "./AboutUs"
import { Home } from "./Home"
import { Search } from "./Search"
import { SellerCrud } from "./SellerCrud"
import {ErrorBoundary} from './ErrorBoundary';

export const Shop =()=>{
    return (
        <>
        <ErrorBoundary>
        <Menu/>
        <Switch>
            <Route exact path="/" component={Home}/>
            <Route path="/seller" component={SellerCrud}/>
            <Route path="/search/:name/:city" component={Search}/>
            <Route path="/aboutus" component = {AboutUs}/>
            <Redirect from="/about" to="/aboutus"/>
            <Route render={()=><h1>OOPS U type Wrong URL in Browser</h1>}/>
        </Switch>
        </ErrorBoundary>
        </>
    )
}