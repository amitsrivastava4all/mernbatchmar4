import React from 'react'
import List from '../components/List';

export const Search = (props)=>{
    console.log('Props are ',props);
    return (<div>
        <h1>Search Page {props.match.params.name} {props.match.params.city}</h1>
        <List/>
    </div>)
}