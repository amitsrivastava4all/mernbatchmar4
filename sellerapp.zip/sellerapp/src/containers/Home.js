import React from 'react'

export const Home = ()=>{
    return (<div>
        <h1>Home Page</h1>
        <img src='https://d39w7f4ix9f5s9.cloudfront.net/dims4/default/31b11ad/2147483647/strip/true/crop/3000x1354+0+0/resize/1440x650!/quality/90/?url=http%3A%2F%2Famazon-blogs-brightspot.s3.amazonaws.com%2F85%2F98%2F9679b8164eb398cbfa4e5e90b3ae%2Fblog-header.jpg'/>
    </div>)
}