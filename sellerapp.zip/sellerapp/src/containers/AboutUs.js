import React from 'react'
import {NavLink} from 'react-router-dom';
import {Route} from 'react-router';
import { Local } from '../components/Local'

export const AboutUs = ()=>{
    return (<div>
        <h1>AboutUs Page</h1>
        <NavLink to="/aboutus/local">About India Location</NavLink>
        &nbsp;
        <NavLink to="/aboutus/remote">About Overseas Location</NavLink>
        <br/>
        <hr/>
        <Route path="/aboutus/local" component={Local}/>
        <Route path="/aboutus/remote" render={()=>{
            return (<>
            <h1> Remote Locations</h1>
            <p>USA , UK</p>
            </>)
        }}/>
    </div>)
}