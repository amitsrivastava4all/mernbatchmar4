import {App} from './App';
import ReactDOM from 'react-dom';
import React from 'react';
//ReactDOM.render(React.createElement(App),
 //document.querySelector('#root'));
// <h1 class='red'/>
//<App mytitle = 'REACT JS'/>
 ReactDOM.render(<App mytitle = 'REACT JS'/>, document.querySelector('#root'));