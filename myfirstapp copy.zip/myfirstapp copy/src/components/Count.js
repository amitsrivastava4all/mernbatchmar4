import React from 'react';
export class Count extends React.Component
{
    constructor(){
        super(); // parent class constructor call
        this.counter = 0;
        this.state = {countValue:this.counter};
        this.fn = this.increment.bind(this);
    }
    increment(){
        console.log('What is this ',this);
        this.counter++;
        this.setState({countValue: this.counter}); // IMMUTABLE
        console.log('Counter is ', this.counter);
    }
    render(){
        console.log('Render Call');
        return (<div>
            <h1>Count is {this.state.countValue}</h1>
            <p>Counter is {this.counter}</p>
            <button onClick={this.fn}>Plus</button>
        </div>)
    }
}