import React from 'react';
export const Footer = ()=>{
    const myStyle = {
        color:'yellow',
        backgroundColor:'red'
    }
    return (
        <div>
            <h1 style={myStyle}>I am Footer</h1>
        </div>
    )
}