import React from 'react';
import './content.css';
export const Content = ()=>{
    return (
        <div>
            <h1 className='mycolor'>I am Content</h1>
        </div>
    )
}