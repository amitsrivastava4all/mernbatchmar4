// module.exports = {
//     add(a,b){
//         return a + b;
//     },
//     sub(a,b){
//         return a - b;
//     }
// }
// module.exports.add = function (a,b){
//     return a + b;
// }
// module.exports.sub = function(a,b){
//     return a - b;
// }
const calc = {};
calc.add = function(a,b){
    return a + b;
}
calc.sub = function(a,b){
    return a -b;
}
module.exports = calc;
