module.exports = function add(a=0,b=0){
    return a + b;
}
// export function add(a=0, b = 0){
//     return a + b;
// }
