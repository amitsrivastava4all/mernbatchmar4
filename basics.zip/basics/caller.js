// const adder = require('./demo');
// //import {add} from './demo';
// //console.log(add(10,20));
// console.log(adder(10,20));

const calc = require('./calc');
console.log(calc.add(10,20));
console.log(calc.sub(100,200));
