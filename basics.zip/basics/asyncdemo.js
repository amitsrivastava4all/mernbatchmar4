const fs = require('fs');
console.log('Before Read a file'); // Sync
fs.readFile('/Users/arnav/Documents/node-codes/basics/demo.js', (err, content)=>{
    if(err){
        console.log('Error is ',err);
    }
    else{
        console.log(content.toString()); // buffer
    }
});

fs.readFile('/Users/arnav/Documents/node-codes/basics/caller.js', (err, content)=>{
    if(err){
        console.log('Error is ',err);
    }
    else{
        console.log(content.toString()); // buffer
    }
});
console.log('After Read');
var a =100;
var b = 200;
var c = a + b;
console.log(c);