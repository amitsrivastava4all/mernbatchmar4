import React from 'react'
import { Input } from '../components/Input'
import  List  from '../components/List'

export const SellerCrud = ()=>{
    return (
        <>
        <h1 className='alert-info text-center'>Seller CRUD</h1>
        <Input/>
        <List/>
        </>
    )
}
