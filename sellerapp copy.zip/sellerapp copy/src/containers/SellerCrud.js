import React from 'react'
import { Input } from '../components/Input'
import  List  from '../components/List'
import { Operations } from '../components/Operations'
import { Result } from '../components/Result'

export const SellerCrud = ()=>{
    return (
        <>
        <h1 className='alert-info text-center'>Seller CRUD</h1>
        <Input/>
        <Operations/>
        <Result/>
        <List/>
        </>
    )
}
