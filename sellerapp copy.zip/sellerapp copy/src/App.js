import logo from './logo.svg';
import './App.css';
import { SellerCrud } from './containers/SellerCrud';

function App() {
  return (
    <div className='container'>
      <SellerCrud/>
    </div>
  );
}

export default App;
