import React, {useRef} from 'react'
import { productAction } from '../actions/productaction';
import { store } from '../models/store';
export const Input = ()=>{
    const id = useRef(0);
    const name = useRef('');
    const descr = useRef('');
    const price = useRef(0.0);
    const url = useRef('');
    const date = useRef('');
    const add = ()=>{
        const data = {
           "id": id.current.value,
           "name": name.current.value,
           "descr": descr.current.value,
           "price": price.current.value,
           "url": url.current.value, 
           "date": date.current.value,
        }
        store.dispatch(productAction(data,'ADD'));
        console.log(data);
    }
    return (
    <>
    <div className='form-group'>
        <label>ID</label>
        <input className='form-control' type='text' placeholder='Type Id' ref={id}/>
    </div>
    <div className='form-group'>
        <label>Name</label>
        <input className='form-control' type='text' placeholder='Type Id' ref={name}/>
    </div>
    <div className='form-group'>
        <label>Descr</label>
        <input  className='form-control'   type='text' placeholder='Type Id' ref={descr}/>
    </div>
    <div className='form-group'>
        <label>Price</label>
        <input  className='form-range'  type='range' min="1" max="100" ref={price}/>
    </div>
    <div className='form-group'>
        <label>Date</label>
        <input  className='form-control' type='date'  ref={date}/>
    </div>
    <div className='form-group'>
        <label>URL</label>
        <input className='form-control' type='text' placeholder='Type Id' ref={url}/>
    </div>
    <div>
        <button onClick={add} className='btn btn-primary'>Add</button>
    </div>
    </>
    )

}