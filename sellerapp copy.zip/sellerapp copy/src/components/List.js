import { connect, useSelector } from "react-redux"

const List = (props)=>{
//    const List = (props)=>{
    const products = useSelector((state)=>state.products); // Using Hooks
    return (
        <>
        { <p>Products are {products?.length}</p> }
        <table className='table table-bordered'>
            <thead className='table-dark'>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Price</th>
                <th>Desc</th>
                <th>Date</th>
                <th>URL</th>
            </tr>
            </thead>
           <tbody>

           </tbody>
        
        
        {products.map(product=>{
            return (
                <tr>
                    <td>{product.id}</td>
                    <td>{product.name}</td>
                    <td>{product.price}</td>
                    <td>{product.descr}</td>
                    <td>{product.date}</td>
                    <td>{product.url}</td>
                </tr>
            )
        })}
        </table>
        {/* <p>Products are {props.products?.length}</p> */}
        </>
    )
}
export default List;


// const mapStateToProps = (state)=>{
//     console.log('Map State To Props ', state);
//     return {
//         'products':state.products?state.products:[]
//     }
// }
// export default connect(mapStateToProps)(List);
//export const parentfn = connect(mapStateToProps)(List);
//export default parentfn(List);

