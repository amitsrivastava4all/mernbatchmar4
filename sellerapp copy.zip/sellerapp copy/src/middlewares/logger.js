export const LoggerMiddleWare = ()=>{
    return next=>{
        return action=>{
            console.log("Time In ::: ", Date.now());
            const result = next(action);
            console.log("Time Out :: ", Date.now());
            return result;
        }
    }
}