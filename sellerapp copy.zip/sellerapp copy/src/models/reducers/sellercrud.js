export const sellerReducer = (state = {'products':[]}, action)=>{
    if(action.type==='ADD'){
        let products = [...state.products];
        products.push(action.payload);
        state =  {'products':products};
        console.log('Reducer is ',state);
        return state;
    }
    return state;
}