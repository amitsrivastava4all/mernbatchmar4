import {createStore} from 'redux';
import { sellerReducer } from './reducers/sellercrud';
export const store = createStore(sellerReducer);
store.subscribe(()=>{
    console.log('Store has been updated ',store.getState());
})