import {applyMiddleware, combineReducers, createStore} from 'redux';
import { LoggerMiddleWare } from '../middlewares/logger';
import { itemReducer } from './reducers/itemcrud';
import { sellerReducer } from './reducers/sellercrud';
import thunk from 'redux-thunk';
//export const store = createStore(sellerReducer); // Single reducer
// multiple reducer
//export const store = createStore(combineReducers(sellerReducer, itemReducer));
export const store = createStore(sellerReducer, applyMiddleware(LoggerMiddleWare, thunk));
store.subscribe(()=>{
    console.log('Store has been updated ',store.getState());
})