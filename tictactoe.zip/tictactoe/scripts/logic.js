window.addEventListener('load',init);

function init(){
    askToTheUser();
    bindEvents();
}

//var buttons;
var isXorZero = true;

function tie(){
    if(buttonClickCount == 9){
        document.getElementById('result').innerText='Game Tie';
    }
    /*for(var i = 0; i<buttons.length; i++){
        if(buttons.length!=0){
            document.getElementById('result').innerText='Game Tie';
        }
    }*/
}

function askToTheUser(){
    var choice = prompt("Enter your Choice X or 0 ");
    if(choice && (choice.toUpperCase() =='X' ||
    choice.toUpperCase() =='0')){
        if(choice.toUpperCase()=='0'){
            isXorZero = false;
        }
    }

}

function bindEvents(){
    // Contain HTML Collection
    var buttons = document.getElementsByTagName('button');
    // Traverse HTML Collection
    for(var i = 0; i<buttons.length; i++){
        // button[0] , button[1], button[2] object
        buttons[i].addEventListener('click', printXorZero);
    }
}
var buttonClickCount = 0;
function printXorZero(){

    if(!isGameOver() && this.innerText.length==0){
    this.innerText = isXorZero?'X':'0';
    isXorZero = !isXorZero;
    buttonClickCount++;
    }

    if(isGameOver()){
        document.
        getElementById('result').innerText='Game Over';
        return ;
    }

}

function isGameOver(){
    var buttons = document.getElementsByTagName('button');
    var gameOver = false;
    if(buttonClickCount>=5){
        tie();
    if(isNotBlank(buttons[0]) &&
     isNotBlank(buttons[1]) && isNotBlank(buttons[2]) && isSame(buttons[0], buttons[1], buttons[2])){

         gameOver   = true;

    }
    else
    if(isNotBlank(buttons[3]) &&
     isNotBlank(buttons[4]) && isNotBlank(buttons[5]) && isSame(buttons[3], buttons[4], buttons[5])){

         gameOver   = true;

    }
    else
    if(isNotBlank(buttons[6]) &&
     isNotBlank(buttons[7]) && isNotBlank(buttons[8]) && isSame(buttons[6], buttons[7], buttons[8])){

         gameOver   = true;

    }
    else
    if(isNotBlank(buttons[0]) &&
     isNotBlank(buttons[3]) && isNotBlank(buttons[6]) && isSame(buttons[0], buttons[3], buttons[6])){

         gameOver   = true;

    }
    else
    if(isNotBlank(buttons[1]) &&
     isNotBlank(buttons[4]) && isNotBlank(buttons[7]) && isSame(buttons[1], buttons[4], buttons[7])){

         gameOver   = true;

    }
    else
    if(isNotBlank(buttons[2]) &&
     isNotBlank(buttons[5]) && isNotBlank(buttons[8]) && isSame(buttons[2], buttons[5], buttons[8])){

         gameOver   = true;

    }
    else
    if(isNotBlank(buttons[0]) &&
     isNotBlank(buttons[4]) && isNotBlank(buttons[8]) && isSame(buttons[0], buttons[4], buttons[8])){

         gameOver   = true;

    }
    else
    if(isNotBlank(buttons[2]) &&
     isNotBlank(buttons[4]) && isNotBlank(buttons[6]) && isSame(buttons[2], buttons[4], buttons[6])){

         gameOver   = true;

    }
}
    return gameOver;
}

function isNotBlank(currentButton){
    return currentButton.innerText.length != 0;
}

function isSame(first, second, third){
    return first.innerText == second.innerText &&
    first.innerText == third.innerText ;
}