import React from 'react';
export const Output = (props)=>{
    return (<h2>{props.msg} </h2>)
}