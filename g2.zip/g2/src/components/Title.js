import React from 'react';
export const Title = ()=>{
    return (<h1 className='alert-info text-center'>Greet App</h1>)
}