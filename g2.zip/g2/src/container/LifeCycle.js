import React from 'react';
export class LifeCycle extends React.Component{
    constructor(){
        super();
        console.log('Lifecycle 1. Cons Call');
        // initalize instance variables

    }
    UNSAFE_componentWillMount(){
        // Borrow some data from the backend (it like preloading of the data)
        // PreInitalization of data for component
        console.log('Lifecycle 2. Will Mount Call');
    }
    render(){
        console.log('Lifecycle 3. Render Call');
        return (<>
        <h2>Life Cycle</h2>
        </>)
    }
    componentDidMount(){
        //Borrow some data from the backend
        console.log('Lifecycle 4. Did Mount');
    }
    componentWillUnmount(){
        console.log("LifeCycle Un Mount Happen");
    }
}