import React, { useRef } from "react";

export class InputWays extends React.Component{
    constructor(){
        super();
        console.log('Smart :::: ',this);
        this.name = null;
        this.setName = nameInput=>{
            this.name = nameInput;
            this.name.focus();
        }
    }
        // this.name = React.createRef();
        // this.age = React.createRef() ;
        // this.salary = React.createRef();

        //old way
        /*let name  = this.;
        let age = this.
        let salary = this.ue;*/
        getData(){

        console.log('Name ',this.name.value);
        //console.log(`Name ${this.name.current.value} Age ${this.age.current.value} Salary ${this.salary.current.value}`);
    }
    render(){
        return (
            <>
            <div className='form-group'>
                <label>Name</label>
                {/* <input className='form-control' type='text' eholder='Type Name Here'/> */}
               /* <input className='form-control' type='text' ref={this.setName}  placeholder='Type Name Here'/>
            </div>
            <div>
            <label>Age</label>
            <input className='form-control' type='text' placeholder='Type Age Here'/>
        </div>
        <div>
            <label>Salary</label>
            <input className='form-control' type='text' placeholder='Type Salary Here'/>
        </div>

        <div>
            {/* <button onClick={this.getData.bind(this)} className='btn btn-primary'>Add</button> */}
            <button onClick={()=>{
                 console.log('Name ',this.name.value);
            }} className='btn btn-primary'>Add</button>

        </div>

        </>
        );
    }
}
