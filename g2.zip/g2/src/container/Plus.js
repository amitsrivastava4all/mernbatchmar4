import React, { useState } from "react";

export const Plus = (props)=>{
    const [counter, setCounter]= useState(0);
    const plusIt = ()=>{

        setCounter(counter+1);
    }
    return (
        <>
         <h3>{counter}</h3>
         <button onClick = {plusIt}>Click</button>
         </>
    )
}

// export class Plus extends React.Component{
//     constructor(){
//         super();
//         this.count = 0;
//         this.state = {counter:0};
//     }
//     plusIt(){
//         this.count++;
//         this.setState({counter:this.count});
//     }
//     render(){
//         return (
//         <>
//         <h3>{this.state.counter}</h3>
//         <button onClick = {this.plusIt.bind(this)}>Click</button>
//         </>
//         )
//     }
// }