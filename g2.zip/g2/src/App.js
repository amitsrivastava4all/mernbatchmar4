import React, { useState } from 'react';
import { Greet } from './container/Greet';
import { InputWays } from './container/InputWays';
import { LifeCycle } from './container/LifeCycle';
import { Plus } from './container/Plus';
export const App = ()=>{

  const [flag,setFlag ]= useState(true);
  return (<div className='container'>
    <button onClick={()=>{
      setFlag(!flag);
    }}>Show/ Hide</button>
    {/* <InputWays/> */}
    {flag?<LifeCycle/>:<Plus/>}
    {/* <LifeCycle/> */}
    {/* <Greet/> */}
    </div>);
}