

import {show} from './b.js';
import {printing} from './c.js';

console.log('I am Already Loaded....');
    document.querySelector('#b1').addEventListener('click', function(){
        var x = show();
    var y = printing();
    document.querySelector('#result').innerText = x + y;
    })

