

 export function show(){
    return 1000;
}
