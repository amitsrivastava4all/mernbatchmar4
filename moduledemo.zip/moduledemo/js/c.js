

export  function printing(){
    return 2000;
}
