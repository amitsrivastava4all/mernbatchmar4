const fs = require('fs');
const path = require('path');
const rootPath= path.normalize(__dirname+"/../..");
const fullPath= path.join(rootPath,'/logs/server.log');
const serverLogStream = fs.createWriteStream(fullPath,{interval:'7d'});
module.exports = serverLogStream;