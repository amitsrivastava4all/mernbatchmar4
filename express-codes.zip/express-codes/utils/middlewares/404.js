/**
 * 404 - File Not found Middleware
 * @param {*} request
 * @param {*} response
 * @param {*} next
 * @author Amit Srivastava
 * @version 1.0
 * @summary This is a Middleware
 */
module.exports = (request, response, next)=>{
    response.send('OOPS U Type Something Wrong....');

}