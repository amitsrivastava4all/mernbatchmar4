const express = require('express');
const userRoutes =express.Router();

const appLogger = require('../utils/logger/applogs')(__filename);
userRoutes.get('/login',(request, response)=>{
    //console.log(request.query);
    let userid = request.query.userid; // QueryString ?userid=amit&password=111
    let password = request.query.password;
    if(userid == password){
        response.send('Welcome '+userid);
    }
    else{
        response.send('Invalid Userid or Password'); // write + end = send
    }

});
userRoutes.post('/login',(request, response)=>{
    appLogger.debug('Inside the Post of Login ' + request.body.userid);
    let userid = request.body.userid;
    let password= request.body.password;
    if(userid == password){
        response.send('Welcome '+userid);
    }
    else{
        response.send('Invalid Userid or Password'); // write + end = send
    }
});
module.exports = userRoutes;
