window.addEventListener('load',bindEvents); // Page Load
// Event Binding (JS)
function bindEvents(){
    document.getElementById('like').addEventListener('click',likePlus);
}



var like = 0;
function likePlus(){
    like++;
    console.log(like);
    document.getElementById('count').innerText = like;
    //window.document.
    //getElementsByTagName('span')[0].innerText=like;
}