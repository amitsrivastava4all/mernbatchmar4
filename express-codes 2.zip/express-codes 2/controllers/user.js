
const messageBundle = require('../locales/en.json');
const appLogger = require('../utils/logger/applogs')(__filename);
const pathUtil = require('../utils/pathutil');
const userController = {
    getLogin(request, response){
        //console.log(request.query);
        let userid = request.query.userid; // QueryString ?userid=amit&password=111
        let password = request.query.password;
        if(userid == password){
            response.send(messageBundle['login.welcome']+userid);
        }
        else{
            response.send(messageBundle['login.fail']); // write + end = send
        }

    },


postLogin(request, response){
    appLogger.debug('Inside the Post of Login ' + request.body.userid);
    let userid = request.body.userid;
    let password= request.body.password;
    if(userid == password){
        request.session.userid = userid;
        // const path = require('path');
        // const parentPath= path.normalize(__dirname+'/..');
        // const fullPath = path.join(parentPath,'/public/dashboard.html');
        // response.sendFile(fullPath);
        //response.render('dashboard',{'uid':userid});
        response.redirect('/dashboard');
        //response.send(messageBundle['login.welcome']+userid);
        //response.send('Welcome '+userid);
    }
    else{
        response.send(messageBundle['login.fail']+userid);
        //response.send('Invalid Userid or Password'); // write + end = send
    }
},
async logout(request, response) {
    if(request.session ){
        try{
            await request.session.destroy();

            response.sendFile(pathUtil.getStaticFullPath('login.html'));
        }
        catch(err){
            console.log('Unable to Logout....', err);
        }
    }

},



dashboard(request, response){
    //console.log(request.body.userid);
    if(request.session.userid){
        response.render('dashboard',{'uid':request.session.userid});
    }
    else{


        response.sendFile(pathUtil.getStaticFullPath('login.html'));
    }

}
}
module.exports = userController;
