const express = require('express');
const expressSession = require('express-session');
require('dotenv').config();
//console.log(typeof express);
const appLogger = require('./utils/logger/applogs')(__filename);
//console.log(appLogger);
const app = express(); // call express function
const morgan = require('morgan');
const morganServerStream = require('./utils/logger/server');
process.on('uncaughtException',(err)=>{

    appLogger.error('UnCaught Exception '+err.message + " "+err.stack);
});
app.use(morgan('combined',{stream: morganServerStream}));
//console.log('App is ', typeof app);
// App represent the application
//app.use(middleware);
// middleware - it is a function (req, res, next)
//const bodyParser = require('body-parser');
//r++;
app.use(express.static('public')); // Static file serve middleware
// app.get('/login',function(request, response){

// });
// app.use(bodyParser.urlencoded({extended:false})); // userid=amit&password=111
// app.use(bodyParser.json());
app.use(express.urlencoded({extended:false})); // userid=amit&password=111
app.use(express.json());
app.use(expressSession({
    secret:process.env.SECRET_KEY,
    cookie:{
        maxAge:1000*60*10 //10min (connect.sid)
    }
}));
app.set('view engine','ejs');
//app.set('views','templatePath'); // if not in view folder
app.use('/',require('./routes/user'));
app.use(require('./utils/middlewares/404'));
const server = app.listen(process.env.PORT || 1234,(err)=>{
    if(err){
        appLogger.debug('Error During Server Listen');
        //console.log('Error During Server Listen');
    }
    else{
        appLogger.debug('Server Started '+server.address().port);
        console.log('Server Started...', server.address().port);
    }
})