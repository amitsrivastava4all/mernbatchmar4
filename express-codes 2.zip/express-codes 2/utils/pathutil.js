module.exports = {
    getStaticFullPath(pagePath){
        const path = require('path');
        const parentPath= path.normalize(__dirname+'/..');
        const fullPath = path.join(parentPath,`/public/${pagePath}`);
        return fullPath;
    }
}