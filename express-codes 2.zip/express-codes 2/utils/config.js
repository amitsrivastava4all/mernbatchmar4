module.exports = {
    ROUTES :{
        USER_ROUTES:{
            LOGIN: '/login',
            DASHBOARD:'/dashboard',
            LOGOUT: '/logout'
        },

    }
}