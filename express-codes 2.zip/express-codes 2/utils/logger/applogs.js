const winston = require('winston');
const {timestamp,label, combine, printf}= winston.format;
const customFormat = printf(({level, message, label, timestamp})=>{
    //console.log('CF',level, message, label,timestamp);
    return `${timestamp} [${label}] ${level} : ${message} `;
});
module.exports = function(moduleName){
    const logger =  winston.createLogger({
        level:'debug',
        transports:[
            new winston.transports.File({
                filename:process.env.APP_DEBUG_LOGS, // DEV
                level:'debug',
                maxsize:20*1024*1024 ,// 20MB
                maxFiles:5
            }),
            new winston.transports.File({
                filename:process.env.APP_ERROR_LOGS, // PROD
                level:'error',
                maxsize:20*1024*1024 ,// 20MB
                maxFiles:5
            }),

        ],
        format:combine(label({label:moduleName}),timestamp(), customFormat)


    });
    return logger;
}