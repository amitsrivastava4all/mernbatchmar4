const express = require('express');
const userRoutes =express.Router();
const messageBundle = require('../locales/en.json');
const appLogger = require('../utils/logger/applogs')(__filename);
const userController = require('../controllers/user');
const {LOGIN, LOGOUT, DASHBOARD} = require('../utils/config').ROUTES.USER_ROUTES;
userRoutes.get(LOGIN,userController.getLogin);
userRoutes.post(LOGIN,userController.postLogin);
userRoutes.get(LOGOUT,userController.logout);
userRoutes.get(DASHBOARD, userController.dashboard);

module.exports = userRoutes;
