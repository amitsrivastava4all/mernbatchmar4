const obj = require('calcbrainmentors21');
const chalk = require('chalk');
console.log(chalk.red("Add "),chalk.blueBright(chalk.italic(obj.add(10,20))));
console.log(chalk.green("Subtract "),chalk.magentaBright(chalk.bold(obj.sub(10,20))));