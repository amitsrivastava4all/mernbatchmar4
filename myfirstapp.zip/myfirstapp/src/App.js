import React from 'react';
import './App.css';
export function App(args){
  console.log('Props is ',args);
  //let title = 'React JS';
  //return React.createElement('h1',null,'Hello React JS');
 // return React.createElement('h1',{className:'red'},'Hello React JS');
//  return React.createElement('h1',{className:'red'}
//  ,React.createElement('p',null, 'Hello React...'));
// return React.createElement('div',null
// ,React.createElement('p',{className:'red'},'Hi React'),
//  React.createElement('h1',null,'Hello React '));
return (<div><p>Hi {args.mytitle}</p><h1>Hello {args.mytitle}</h1></div>)
//<h1><p>Hello React</p></h1>
 // <h1> Hello React JS </h1>
}

