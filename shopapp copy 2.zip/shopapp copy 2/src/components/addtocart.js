import React,{useState} from 'react'
import { ItemContext } from '../utils/context';

export const AddToCart = ()=>{
    const [cartFlag, updateCart] = useState(false);

    const update = ()=>{
        updateCart(!cartFlag);
    }

    return <ItemContext.Consumer>
        {
            (value)=>{
                return (
                    <button onClick = {()=>{
                        update();
                        value.updateItemCount(!cartFlag?1:-1);
                    }} className = 'btn btn-success'>{!cartFlag?'Add to Cart':'Remove From Cart'} </button>
                )
            }
        }
        </ItemContext.Consumer>
}