import React from 'react'
import { ItemContext } from '../../utils/context'

export const ItemInCart = ()=>{
    return (
    <ItemContext.Consumer>{
        (value)=>{
            return ( <p className='alert-success'>Items in Cart {value.itemCartCount}</p>)
        }
        }
   
    </ItemContext.Consumer>
    )
}