import React from 'react'
import PropTypes from 'prop-types';
export const TotalItem = ({len})=>{
    return (<h3>Total Items are {len}</h3>)
}
TotalItem.defaultProps = {
    len:0
}
TotalItem.propTypes = {
    len:PropTypes.number.isRequired
}