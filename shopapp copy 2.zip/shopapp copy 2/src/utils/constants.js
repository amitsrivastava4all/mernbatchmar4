export const CONFIG = {
    URLS :{
        // PRODUCT:'awsmachineip:port/application'
       // PRODUCT:'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/mobiles.json',
       PRODUCT:'/mobiles.json',
        ADD_PRODUCT:'' // On Node JS and Store data in DB
    }
}