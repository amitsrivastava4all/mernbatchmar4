import axios from 'axios';
import { CONFIG } from './constants';

let axiosObject ;
export const axiosSettings = ()=>{
    // Global Set
    axios.defaults.baseURL = 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master';
    //axios.defaults.headers['Authorization'] = '11111';
    axios.defaults.headers.post['Content-Type'] = 'application/json';
   
    axiosObject = axios.create();
    axiosObject.defaults.baseURL = '';
    axiosObject.defaults.timeout = 3000;
}

export const loadInterceptors = ()=>{
    const requestInterceptor = axios.interceptors.request.use(request=>{
        console.log('Request Interceptor Call');
        request.tokenId = 'A11111';
        return request;
    }, err=>{
        console.log('request error ',err);
        return Promise.reject(err);
    })

    setTimeout(()=>{
        console.log('Interceptor Ejected');
        axios.interceptors.request.eject(requestInterceptor);
    }, 7000);

    axios.interceptors.response.use(response=>{
        //request.tokenId = 'A11111';
        console.log('Response Interceptor call');
        return response;
    }, err=>{
        console.log('response error ',err);
        return Promise.reject(err);
    })
}

// GET - Read
export const getProducts = ()=>{
    //const promise = axiosObject.get(CONFIG.URLS.PRODUCT);
    //const promise = axios.get(CONFIG.URLS.PRODUCT);
    //return promise;

    // return axiosObject({
    //     method:'GET',
    //     url:CONFIG.URLS.PRODUCT,
    //     timeout:3000 , // 3000 ms equal to 3 sec
    //     maxContentLength:5000, // 5000 bytes,


    // })

    return axios({
        method:'GET',
        url:CONFIG.URLS.PRODUCT,
        timeout:3000 , // 3000 ms equal to 3 sec
        maxContentLength:5000, // 5000 bytes,


    })
}
// const consolidatePromise = axios.all([axios.get('x'), axios.post('y')]);
// consolidatePromise.then(responseArray=>{

// }).catch(err=>{
    
// })

// POST - Data Send
export const addProduct = (productObject)=>axios.post(CONFIG.URLS.ADD_PRODUCT,productObject);
