import React, {useEffect, useState} from 'react';
import { ItemInCart } from '../components/product/itemincart';
import { List } from '../components/product/list';
import { Search } from '../components/product/search';
import { TotalItem } from '../components/product/totalitem';
import { getProducts } from '../utils/ajax';
import { ItemContext } from '../utils/context';


export const ProductPage = ()=>{
    const [totalItemInCartCount, updateCount]= useState(0);
    const [products, setProducts] = useState([]);
   
    const updateItemsInCart = (val)=>{
        console.log('Value is ',val);
        //totalItemInCartCount+=val;
        updateCount(totalItemInCartCount + val);
        console.log('Value rec from add to cart ', totalItemInCartCount);
    }
    useEffect(() => {
        const promise = getProducts();
        promise.then(response=>{
            console.log('Axios Data is ',response.data);
            setProducts(response.data['mobiles']);
        }).catch(err=>{
            console.log('INvalid JSON ', err);
        });
        /*setTimeout(()=>{
            const promise = fetch(CONFIG.URLS.PRODUCT);

        promise.then(response=>{
            const pr = response.json();
            pr.then(data=>{
                console.log('Data is ',data['mobiles']);
                setProducts(data['mobiles']);
            }).catch(err=>{
                console.log('INvalid JSON ');
            })

        }).catch(err=>{
                console.log('Server Error ',err);
        })
        }, 5000);
        */
    }, [])
    return (<div>
            <ItemContext.Provider value={{itemCartCount:totalItemInCartCount, updateItemCount:updateItemsInCart}}>
            <ItemInCart/>
            <Search/>
            <List products= {products}/>
            <TotalItem len= {products.length} />
            </ItemContext.Provider>
    </div>);
}
