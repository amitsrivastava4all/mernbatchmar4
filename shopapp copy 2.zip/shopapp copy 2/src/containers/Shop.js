import React from 'react'
import { ProductPage } from './ProductPage'

export const Shop = ()=>{
    return (
    <div className = 'container'>
        <h1 className = 'alert-info text-center'> Shop App</h1>
        <ProductPage/>
    </div>)
}