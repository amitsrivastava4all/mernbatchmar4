import React from "react";
import { Input } from "../components/Input";
import { Operations } from "../components/Operartion";
import { Output } from "../components/Output";
import { Title } from "../components/Title";

export class Greet extends React.Component{
    constructor(){
        super();
        // this.firstName = '';
        // this.lastName = '';
        this.names = {first:'', last:''};
        this.state = {msg:''};

    }

    takeInputData(event, lbl){
        console.log('label is ',lbl);
        this.names[lbl] = event.target.value;
        //this.firstName =  event.target.value;
        console.log("I am Taking TextBox Value Here ",this.names);
        this.setState({msg:''});
    }

    sayWelcome(){
        let msg = 'Welcome ';
        let fullName = '';
        for(let key in this.names){
            let name = this.names[key];
            name = this.properCase(name);
            fullName += name+ " ";
        }
        msg = msg + fullName;
        console.log('Msg is ',msg);
        this.setState({msg:msg});
    }

    properCase(name){
        return name.charAt(0).toUpperCase() + name.substring(1).toLowerCase();
    }

    clearAll(){
        this.names = {first:'', last:''};
        this.setState({msg:''});
    }

    render(){
        return (
            <>
            <Title/>
            <Input myname={this.names.first}  lbl="First" inputfn= {this.takeInputData.bind(this)}/>
            <Input myname={this.names.last}  lbl="Last" inputfn= {(event, lbl)=>{
                this.takeInputData(event, lbl);
            }}/>
            <Operations click={this.sayWelcome.bind(this)} lbl = "Greet" myClass="btn btn-primary"/> &nbsp;
            <Operations click={this.clearAll.bind(this)} lbl = "ClearAll" myClass="btn btn-secondary"/>
            <Output msg = {this.state.msg}/>
            </>
        )
    }
}