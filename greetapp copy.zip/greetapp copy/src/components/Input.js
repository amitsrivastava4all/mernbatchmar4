import React from 'react';
export const Input  = ({lbl, inputfn, myname})=>{
    let placeHolder = `Type ${lbl} Name Here`;
    return (
        <div className='form-group'>
            <label>{lbl} Name</label>
            <input value={myname} onChange={(event)=>{
                inputfn(event, lbl.toLowerCase());
            }} className='form-control' type = 'text' placeholder={placeHolder}/>
        </div>
    )
}