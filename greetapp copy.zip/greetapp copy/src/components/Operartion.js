import React from 'react';
export const Operations = ({lbl, myClass, click})=>{
    return (<button onClick = {click} className={myClass}>{lbl}</button>);
}