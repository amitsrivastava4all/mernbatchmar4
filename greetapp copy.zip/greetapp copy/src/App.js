import React from 'react';
import { Greet } from './container/Greet';
export const App = ()=>{
  return (<div className='container'>
    <Greet/>
    </div>);
}