import React,{useEffect, useState} from 'react'

export const  A=React.memo(()=> {
    const [x, setUpdate] = useState(0);
    useEffect(()=>{
        console.log("DidMount Call");
    },[]);
    useEffect(()=>{
        console.log("X Watch Call");
    },[x]);

    useEffect(()=>{
        console.log("All Update (DidUpdate)");
    });

    useEffect(() => {
       return ()=>{
           console.log('Will UnMount');
       }
    }, [])
   
    const [y, setChange] = useState(0);
    const updateIt = ()=>{
        setUpdate(x+1);
        
    }
    const update2 = ()=>{
        setChange(y+10);
        
    }
    return (
        <div>
            <button onClick={updateIt}>Click Me</button>
            <button onClick={update2}>Click Me 2</button>
            <h1> Functional Life Cycle {x} and {y}</h1>
        </div>
    )
}
);