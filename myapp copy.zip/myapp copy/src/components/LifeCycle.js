import React from 'react';

export class LifeCycle extends React.PureComponent{
//React.Component{
    constructor(props){
        super(props);
        this.count = 0;
        this.state ={counter:this.count};
        console.log('1. Constructor call');
    }
    static getDerivedStateFromProps(nextProps, nextState){
        console.log('getDerivedStateFromProps (Will Mount) + (Will Rec Props)');
        
    }
    /*componentWillMount(){
        console.log('2. Component will mount call');
    }*/
    plus(){
        this.count++;
        this.setState({counter:this.count});
    }
    render(){
        console.log('3. Render Call');
        return (<>
        <h1>Life Cycle Demo {this.state.counter}</h1>
        <button onClick={this.plus.bind(this)}>Change It</button>
        </>);
    }
    componentDidMount(){
        console.log('4. Did Mount Call');
        
    }

    componentWillUnmount(){
        console.log('Last Component will unmount when it is unmounting.');
    }
    UNSAFE_componentWillReceiveProps(){
        console.log('Props Recieve from parent');
    }

    componentWillUpdate(){
        console.log('Will UPdate');
    }

    // shouldComponentUpdate(nextProps, nextState){
    //     console.log('Updation Happens ',this.state, '' , nextState);
    //     if( this.state !=nextState)
    //     return true;
    //     else
    //     return false;
    //     //return true;
    // }
}