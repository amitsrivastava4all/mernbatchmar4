import logo from './logo.svg';
import './App.css';

import { A } from './components/A';
import React, {useState} from 'react'
import { LifeCycle } from './components/LifeCycle';

function App() {
  const [flag, setFlag] = useState(true);
  const showHide = ()=>{
    setFlag(!flag);
  }
  return (
    //  <LifeCycle x = "10"/>
    <>
    {flag?<A/>:<LifeCycle/>}
    <button onClick={showHide}>Show/Hide</button>
  
  
  </>
  );
}

export default App;
