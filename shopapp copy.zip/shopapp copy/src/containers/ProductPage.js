import React, {useEffect, useState} from 'react';
import { ItemInCart } from '../components/product/itemincart';
import { List } from '../components/product/list';
import { Search } from '../components/product/search';
import { TotalItem } from '../components/product/totalitem';
import { CONFIG } from '../utils/constants';

export const ProductPage = ()=>{

    const [products, setProducts] = useState([]);

    useEffect(() => {
        setTimeout(()=>{
            const promise = fetch(CONFIG.URLS.PRODUCT);

        promise.then(response=>{
            const pr = response.json();
            pr.then(data=>{
                console.log('Data is ',data['mobiles']);
                setProducts(data['mobiles']);
            }).catch(err=>{
                console.log('INvalid JSON ');
            })

        }).catch(err=>{
                console.log('Server Error ',err);
        })
        }, 5000);
        
    }, [])
    return (<div>
            <ItemInCart/>
            <Search/>
            <List products= {products}/>
            <TotalItem len= {products.length} />

    </div>);
}
