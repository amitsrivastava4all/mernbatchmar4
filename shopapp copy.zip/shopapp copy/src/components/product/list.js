import React from 'react'
import { Item } from './item'

export const List =(props)=>{
    return (
        <>
        {props.products.length===0?<p>No Product Found</p>:<p>Products are ::: {props.products.length} </p>}
            <div>
                {props.products.map(product=>{
                    return (
                        
                       <Item product = {product}/>
                    )
                })}
            </div>
        </>
    )
}