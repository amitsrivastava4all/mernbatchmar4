import React from 'react'

export const ItemInCart = ()=>{
    return (<p className='alert-success'>Items in Cart 0</p>)
}