import React from 'react';

export const Search = ()=>{
    return (
        <>
    <div className = 'form-group'>
            <label>Search Product by Name</label>
            <input className='form-control' type='text' placeholder='Type to Search any Product'/>
            
        </div>
        <div className='form-group'>
        <button className = 'btn btn-primary'>Search</button>
            &nbsp;
            <button className = 'btn btn-secondary'>Reset All</button>
        </div>
        </>
        )
}