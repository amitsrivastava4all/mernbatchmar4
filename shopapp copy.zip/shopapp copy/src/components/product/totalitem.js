import React from 'react'

export const TotalItem = ({len})=>{
    return (<h3>Total Items are {len}</h3>)
}