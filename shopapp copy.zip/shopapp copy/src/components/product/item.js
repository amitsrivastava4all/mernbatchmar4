import React from 'react'
import { AddToCart } from '../addtocart'

export const Item = ({product})=>{
    const myStyle = {
        width:'100px',
        height:'100px'
    }
    return (
        <div className='row'>
          <div className = 'col'>
          <img style = {myStyle}  src={product.url}/>
              </div>  
        <div className = 'col'>
        <label>{product.price}</label>
        &nbsp;
        <AddToCart/>
        </div>
        
    </div>
    )
}