import React from 'react'

export const AddToCart = ()=>{
    return <button className = 'btn btn-success'>Add to Cart</button>
}