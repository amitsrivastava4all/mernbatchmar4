import React from 'react';
import { Shop } from './containers/Shop';

const App = ()=>{
    return (<Shop/>)
}
export default App;