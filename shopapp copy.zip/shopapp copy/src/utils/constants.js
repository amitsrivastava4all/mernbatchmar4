export const CONFIG = {
    URLS :{
        PRODUCT:'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/mobiles.json'
    }
}