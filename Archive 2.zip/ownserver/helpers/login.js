module.exports = function login(userid, password){
    if(userid == password){
        return "Welcome "+userid;
    }
    else{
        return "Invalid Userid or Password";
    }
}