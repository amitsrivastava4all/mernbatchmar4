module.exports = function serverStaticFiles(url, response){
    const path =require('path');
    const fs = require('fs');
    if(url == '/'){
        url ='/index.html';
    }
    const fullPath = path.join(__dirname,'/public'+url);
    console.log(fullPath);
    const readStream = fs.createReadStream(fullPath);
    readStream.pipe(response);

}