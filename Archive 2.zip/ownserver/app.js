const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const options = {
    key: fs.readFileSync(path.join(__dirname,'/cert/key.pem')),
    cert:fs.readFileSync(path.join(__dirname,'/cert/cert.pem'))
}
const staticServerFile = require('./staticserve');
const login = require('./helpers/login');
function handleRequestResponse(request, response){
    //console.log('Request Comes ');  
    console.log('Request for ', request.url);
    const SUCCESS_CODE = 200;
    if(request.url.startsWith('/userlogin') && request.method =='GET'){
       
        console.log('I am in Login ', request.url);
        const url = require('url');
        const userObject =url.parse(request.url, true);
        console.log(userObject.query);
        const message  = login(userObject.query.userid, userObject.query.password);
        response.write(message);
        response.end();
    }
    else
    if(request.url == '/userlogin' && request.method =='POST'){
        let requestData = '';
        request.on('data',chunk=>{
            requestData+=chunk;
        });
        request.on('end',()=>{
            const queryString = require('querystring');
            const userObject = queryString.parse(requestData);
            const message = login(userObject.userid, userObject.password);
            response.write(message);
            response.end();

        });
    }
    else{
     response.writeHead(SUCCESS_CODE, "{'content-type':'text/html'}");
     staticServerFile(request.url, response);  
    }
     // response.write('<h1>Hello Client</h1>');
    // response.write('<h3>Hi Client</h3>');
    // response.end();
}
//const server = http.createServer(handleRequestResponse);
const server = https.createServer(options, handleRequestResponse);
server.listen(process.env.PORT || 4343,()=>{
    console.log('Server Started....', server.address().port);
})